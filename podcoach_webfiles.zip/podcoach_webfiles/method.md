# Edit gradient colors
    templatemo-style.css

# Edit video source
    swap video.mp4 source